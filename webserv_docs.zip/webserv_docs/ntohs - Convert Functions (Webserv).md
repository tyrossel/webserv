# ntohs
---
~~~cpp
#include <arpa/inet.h>

uint16_t ntohs(uint16_t netshort);
~~~
-  converts the unsigned short integer netshort from network byte order to host byte order.
---
### [Source](https://linux.die.net/man/3/htons)
---
## [[Convert Functions - Webserv]]
## [[Functions - Webserv (CPP)]]
## [[Webserv]]