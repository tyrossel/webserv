# htonl
---
~~~cpp
#include <arpa/inet.h>

uint32_t htonl(uint32_t hostlong);
~~~
-  converts the unsigned integer hostlong from host byte order to network byte order
---
### [Source](https://linux.die.net/man/3/htons)
---
## [[Convert Functions - Webserv]]
## [[Functions - Webserv (CPP)]]
## [[Webserv]]