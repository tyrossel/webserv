# Convert Functions
---
- convert values between host and network byte order
---
## [[htons - Convert Functions (Webserv)]]
## [[htonl - Convert Functions (Webserv)]]
## [[ntohs - Convert Functions (Webserv)]]
## [[ntohl - Convert Functions (Webserv)]]
---
## [[Functions - Webserv (CPP)]]
## [[Webserv]]