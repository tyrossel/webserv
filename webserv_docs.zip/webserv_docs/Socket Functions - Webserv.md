# Socket Functions
---
## [[socket() - Socket (Webserv)]]
## [[accept() - Socket (Webserv)]]
## [[listen() - Socket (Webserv)]]
## [[send() - Socket (Webserv)]]
## [[bind() - Socket (Webserv)]]
## [[recv() - Socket (Webserv)]]
## [[connect() - Socket (Webserv)]]
## [[setsockopt() - Socket (Webserv)]]
## [[getsockname() - Socket (Webserv)]]
---
## [[Functions - Webserv (CPP)]]
## [[Webserv]]