# Data Server Sends to CGI
---
- Three ways to send data to CGI program 
	- environment variables
	- standard input
	- command-line arguments

#### Environment variables
- most common method used to pass data about a request to our CGI program
- data comes fro the server software itself, from the network socket connectin the client to server, and from the URL that was used to access the CGI program
- identified by character strings and have character string values

#### Standard input
- HTML forms that use POST method send their encoded information using the standard input
---
### [Source](http://www.mnuwer.dbasedeveloper.co.uk/dlearn/web/session01.htm)
---
## [[Common Gateway Interface (CGI)]]
## [[Webserv]]