# Kernel Functions
---
## [[kqueue() - Webserv]]
## [[kevent() - Webserv]]
---
## [[Functions - Webserv (CPP)]]
## [[Webserv]]