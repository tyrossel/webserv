# ntohl
---
~~~cpp
#include <arpa/inet.h>

uint32_t ntohl(uint32_t netlong);
~~~
-  converts the unsigned integer netlong from network byte order to host byte order.
---
### [Source](https://linux.die.net/man/3/htons)
---
## [[Convert Functions - Webserv]]
## [[Functions - Webserv (CPP)]]
## [[Webserv]]